<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Подключение к базе данных
$pdo = new PDO("mysql:host=localhost;dbname=driving_school;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получение информации о пользователе
$stmt = $pdo->prepare("
    SELECT s.*, c.title as course_title, i.name as instructor_name
    FROM students s
    LEFT JOIN courses c ON s.course_id = c.id
    LEFT JOIN instructors i ON s.instructor_id = i.id
    WHERE s.id = ?
");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Получение уроков ученика
$lessons_stmt = $pdo->prepare("
    SELECT l.topic, l.date_lesson, l.status, i.name as instructor_name
    FROM lessons l
    LEFT JOIN instructors i ON l.instructor_id = i.id
    WHERE l.student_id = ?
    ORDER BY l.date_lesson DESC
");
$lessons_stmt->execute([$user_id]);
$lessons = $lessons_stmt->fetchAll();

// Получение экзаменов ученика
$exams_stmt = $pdo->prepare("
    SELECT date_exam, result, notes
    FROM exams
    WHERE student_id = ?
    ORDER BY date_exam DESC
");
$exams_stmt->execute([$user_id]);
$exams = $exams_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Личный кабинет — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <?php include 'includes/header.php'; ?>

  <main class="flex-grow-1 py-5">
    <div class="container">
      <h1 class="mb-4">Добро пожаловать, <?= htmlspecialchars($user_name) ?>!</h1>

      <!-- Информация о пользователе -->
      <div class="row mb-4">
        <div class="col-md-8">
          <div class="card shadow">
            <div class="card-header bg-primary text-white">
              <h5>Ваши данные</h5>
            </div>
            <div class="card-body">
              <p><strong>Имя:</strong> <?= htmlspecialchars($user['name']) ?></p>
              <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
              <p><strong>Телефон:</strong> <?= htmlspecialchars($user['phone']) ?></p>
              <p><strong>Курс:</strong> <?= htmlspecialchars($user['course_title'] ?? 'Не выбран') ?></p>
              <p><strong>Инструктор:</strong> <?= htmlspecialchars($user['instructor_name'] ?? 'Не назначен') ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow text-center">
            <div class="card-body">
              <img src="img/student_avatar_placeholder.png"<?= urlencode($user_name[0]) ?>" class="rounded-circle mb-3" alt="Avatar">
              <h6><?= htmlspecialchars($user_name) ?></h6>
              <p class="text-muted">Ученик</p>
              <a href="logout.php" class="btn btn-outline-danger btn-sm">Выйти</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Уроки -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card shadow">
            <div class="card-header bg-success text-white">
              <h5>Уроки</h5>
            </div>
            <div class="card-body">
              <?php if ($lessons): ?>
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Тема</th>
                      <th>Дата</th>
                      <th>Инструктор</th>
                      <th>Статус</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($lessons as $lesson): ?>
                      <tr>
                        <td><?= htmlspecialchars($lesson['topic']) ?></td>
                        <td><?= date('d.m.Y H:i', strtotime($lesson['date_lesson'])) ?></td>
                        <td><?= htmlspecialchars($lesson['instructor_name']) ?></td>
                        <td>
                          <span class="badge 
                            <?= $lesson['status'] === 'Проведён' ? 'bg-success' : 
                               ($lesson['status'] === 'Отменён' ? 'bg-danger' : 'bg-warning') ?>">
                            <?= htmlspecialchars($lesson['status']) ?>
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              <?php else: ?>
                <p>У вас пока нет уроков.</p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Экзамены -->
      <div class="row">
        <div class="col-12">
          <div class="card shadow">
            <div class="card-header bg-info text-white">
              <h5>Экзамены</h5>
            </div>
            <div class="card-body">
              <?php if ($exams): ?>
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Дата экзамена</th>
                      <th>Результат</th>
                      <th>Комментарии</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($exams as $exam): ?>
                      <tr>
                        <td><?= date('d.m.Y H:i', strtotime($exam['date_exam'])) ?></td>
                        <td>
                          <span class="badge 
                            <?= $exam['result'] === 'Сдан' ? 'bg-success' : 
                               ($exam['result'] === 'Не сдан' ? 'bg-danger' : 'bg-warning') ?>">
                            <?= htmlspecialchars($exam['result']) ?>
                          </span>
                        </td>
                        <td><?= htmlspecialchars($exam['notes'] ?? 'Нет') ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              <?php else: ?>
                <p>У вас пока нет экзаменов.</p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <?php include 'includes/footer.php'; ?>