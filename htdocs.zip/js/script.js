// Анимация при загрузке страницы
document.addEventListener('DOMContentLoaded', function () {
    // Плавное появление элементов
    const fadeElements = document.querySelectorAll('.card, .hero-section, h1, h2, p');
    fadeElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        setTimeout(() => {
            el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, 200 * index);
    });

    // Плавный скролл к якорям
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Анимация при наведении на карточки
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'scale(1.03)';
            card.style.boxShadow = '0 10px 20px rgba(0,0,0,0.15)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'scale(1)';
            card.style.boxShadow = 'none';
        });
    });

    // Слайдер отзывов (если используется)
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slider-item');
    if (slides.length > 0) {
        showSlide(slideIndex);
    }

    function moveSlide(n) {
        showSlide(slideIndex += n);
    }

    function showSlide(n) {
        if (n >= slides.length) slideIndex = 0;
        if (n < 0) slideIndex = slides.length - 1;

        slides.forEach((slide, index) => {
            slide.style.display = 'none';
        });

        slides[slideIndex].style.display = 'block';
    }

    // Вишенка: анимация при клике на логотип
    const logo = document.querySelector('.navbar-brand img');
    if (logo) {
        logo.addEventListener('click', function () {
            // Создаём всплывающий эффект
            const bubble = document.createElement('div');
            bubble.style.position = 'absolute';
            bubble.style.width = '50px';
            bubble.style.height = '50px';
            bubble.style.borderRadius = '50%';
            bubble.style.backgroundColor = 'rgba(255, 193, 7, 0.5)';
            bubble.style.top = '50%';
            bubble.style.left = '50%';
            bubble.style.transform = 'translate(-50%, -50%)';
            bubble.style.zIndex = '1000';
            bubble.style.pointerEvents = 'none';
            bubble.style.animation = 'bubble-pop 0.6s ease-out';
            document.body.appendChild(bubble);

            // Удаляем элемент после анимации
            setTimeout(() => {
                bubble.remove();
            }, 600);

            // Добавляем стиль анимации, если его нет
            if (!document.querySelector('#bubble-style')) {
                const style = document.createElement('style');
                style.id = 'bubble-style';
                style.textContent = `
                    @keyframes bubble-pop {
                        0% { transform: translate(-50%, -50%) scale(0.1); opacity: 1; }
                        100% { transform: translate(-50%, -50%) scale(3); opacity: 0; }
                    }
                `;
                document.head.appendChild(style);
            }
        });
    }
});