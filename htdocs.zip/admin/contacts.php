<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$page_title = "Управление сообщениями - Админ-панель";
include '../includes/header.php';

require_once '../includes/db.php';

$database = new Database();
$db = $database->getConnection();

// Обработка форм
if ($_POST) {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'update_status') {
            $query = "UPDATE contacts SET status = ? WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->bindParam(1, $_POST['status']);
            $stmt->bindParam(2, $_POST['id']);
            $stmt->execute();
        } elseif ($_POST['action'] == 'delete') {
            $query = "DELETE FROM contacts WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->bindParam(1, $_POST['id']);
            $stmt->execute();
        }
    }
}

$query = "SELECT * FROM contacts ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$contacts = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <header class="admin-header">
            <div class="admin-logo">Админ-панель</div>
            <nav class="admin-nav">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="cottages.php">Коттеджи</a></li>
                    <li><a href="bookings.php">Бронирования</a></li>
                    <li><a href="services.php">Услуги</a></li>
                    <li><a href="gallery.php">Галерея</a></li>
                    <li><a href="reviews.php">Отзывы</a></li>
                    <li><a href="contacts.php">Сообщения</a></li>
                    <li><a href="logout.php">Выход</a></li>
                </ul>
            </nav>
        </header>
        
        <div class="admin-content">
            <h1 class="admin-page-title">Управление сообщениями</h1>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Имя</th>
                            <th>Email</th>
                            <th>Телефон</th>
                            <th>Тема</th>
                            <th>Сообщение</th>
                            <th>Статус</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($contacts as $row): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone']); ?></td>
                            <td><?php echo htmlspecialchars($row['subject']); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['message'], 0, 100)) . (strlen($row['message']) > 100 ? '...' : ''); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="new" <?php echo $row['status'] == 'new' ? 'selected' : ''; ?>>Новое</option>
                                        <option value="read" <?php echo $row['status'] == 'read' ? 'selected' : ''; ?>>Прочитано</option>
                                        <option value="replied" <?php echo $row['status'] == 'replied' ? 'selected' : ''; ?>>Отвечено</option>
                                    </select>
                                </form>
                            </td>
                            <td><?php echo $row['created_at']; ?></td>
                            <td>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Удалить сообщение?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>