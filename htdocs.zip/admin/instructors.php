<?php require_once 'config.php'; ?>

<?php
// Получение всех инструкторов
$stmt = $pdo->query("
    SELECT id, name, experience_years, categories, bio
    FROM instructors
    ORDER BY id
");
$instructors = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Инструкторы — Админка</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 bg-dark text-white p-3">
        <h5>Админ-панель</h5>
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link text-white" href="dashboard.php">Главная</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="users.php">Ученики</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white active" href="instructors.php">Инструкторы</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="export_csv.php?table=students">Экспорт учеников</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="export_csv.php?table=instructors">Экспорт инструкторов</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="../logout.php">Выйти</a>
          </li>
        </ul>
      </div>
      <div class="col-md-10 p-4">
        <h2>Список инструкторов</h2>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Имя</th>
              <th>Стаж (лет)</th>
              <th>Категории</th>
              <th>Описание</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($instructors as $instructor): ?>
              <tr>
                <td><?= $instructor['id'] ?></td>
                <td><?= htmlspecialchars($instructor['name']) ?></td>
                <td><?= $instructor['experience_years'] ?></td>
                <td><?= htmlspecialchars($instructor['categories']) ?></td>
                <td><?= htmlspecialchars($instructor['bio']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <a href="export_csv.php?table=instructors" class="btn btn-success mt-3">Экспорт в CSV</a>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>