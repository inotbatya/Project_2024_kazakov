<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$page_title = "Управление галереей - Админ-панель";
include '../includes/header.php';

require_once '../includes/db.php';

$database = new Database();
$db = $database->getConnection();

// Обработка форм
if ($_POST) {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'create') {
            $query = "INSERT INTO gallery (title, image, category, description) VALUES (?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            $stmt->execute([
                $_POST['title'],
                $_POST['image'],
                $_POST['category'],
                $_POST['description']
            ]);
        } elseif ($_POST['action'] == 'update') {
            $query = "UPDATE gallery SET title = ?, image = ?, category = ?, description = ? WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([
                $_POST['title'],
                $_POST['image'],
                $_POST['category'],
                $_POST['description'],
                $_POST['id']
            ]);
        } elseif ($_POST['action'] == 'delete') {
            $query = "DELETE FROM gallery WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$_POST['id']]);
        }
    }
}

$query = "SELECT * FROM gallery ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$gallery = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <header class="admin-header">
            <div class="admin-logo">Админ-панель</div>
            <nav class="admin-nav">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="cottages.php">Коттеджи</a></li>
                    <li><a href="bookings.php">Бронирования</a></li>
                    <li><a href="services.php">Услуги</a></li>
                    <li><a href="gallery.php">Галерея</a></li>
                    <li><a href="reviews.php">Отзывы</a></li>
                    <li><a href="contacts.php">Сообщения</a></li>
                    <li><a href="logout.php">Выход</a></li>
                </ul>
            </nav>
        </header>
        
        <div class="admin-content">
            <h1 class="admin-page-title">Управление галереей</h1>
            
            <div class="form-container">
                <h3>Добавить изображение</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="id" value="">
                    <div class="form-group">
                        <label for="title">Заголовок</label>
                        <input type="text" id="title" name="title">
                    </div>
                    <div class="form-group">
                        <label for="image">Путь к изображению</label>
                        <input type="text" id="image" name="image" required>
                    </div>
                    <div class="form-group">
                        <label for="category">Категория</label>
                        <select id="category" name="category">
                            <option value="rooms">Коттеджи</option>
                            <option value="nature">Природа</option>
                            <option value="services">Услуги</option>
                            <option value="events">Мероприятия</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="description">Описание</label>
                        <textarea id="description" name="description" rows="2"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Добавить изображение</button>
                    </div>
                </form>
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Изображение</th>
                            <th>Заголовок</th>
                            <th>Категория</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($gallery as $row): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <div style="width: 100px; height: 60px; background: #e0f7fa; display: flex; align-items: center; justify-content: center; border-radius: 5px;">
                                    🖼️
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td>
                                <a href="#" class="btn btn-warning" onclick="editImage(<?php echo $row['id']; ?>, '<?php echo addslashes($row['title']); ?>', '<?php echo addslashes($row['image']); ?>', '<?php echo $row['category']; ?>', '<?php echo addslashes($row['description']); ?>')">Редактировать</a>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Удалить изображение?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    function editImage(id, title, image, category, description) {
        document.querySelector('input[name="action"]').value = 'update';
        document.querySelector('input[name="id"]').value = id;
        document.querySelector('input[name="title"]').value = title;
        document.querySelector('input[name="image"]').value = image;
        document.querySelector('select[name="category"]').value = category;
        document.querySelector('textarea[name="description"]').value = description;
        
        document.querySelector('.form-container h3').textContent = 'Редактировать изображение';
        document.querySelector('.form-container button[type="submit"]').textContent = 'Обновить изображение';
    }
    </script>
</body>
</html>