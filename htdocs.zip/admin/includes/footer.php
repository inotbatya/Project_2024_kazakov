  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; <?= date('Y') ?> DrivePro. Все права защищены.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/script.js"></script>
</body>
</html>