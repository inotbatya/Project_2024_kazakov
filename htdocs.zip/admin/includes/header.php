<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $title ?? 'DrivePro — Автошкола'; ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
              <li class="nav-item"><a class="nav-link btn btn-outline-light ms-2" href="dashboard.php">Личный кабинет</a></li>
            <?php else: ?>
              <li class="nav-item"><a class="nav-link btn btn-outline-light ms-2" href="login.php">Войти</a></li>
            <?php endif; ?>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент будет вставлен сюда -->
  <main class="flex-grow-1">