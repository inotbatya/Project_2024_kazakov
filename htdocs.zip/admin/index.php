<?php
$page_title = "База отдыха 'Радужный' - Отдых на природе";
$page_description = "Отдых на природе в Базе отдыха 'Радужный'. Уютные коттеджи, баня, рыбалка.";
include 'includes/header.php';
?>

<div class="hero-section">
    <div class="hero-content">
        <h2>Добро пожаловать в базу отдыха "Радужный"!</h2>
        <p>Идеальное место для отдыха на природе в Московской области</p>
    </div>
</div>

<div class="main-content">
    <h1 class="page-title">О базе отдыха</h1>
    
    <blockquote style="background: #f8f9fa; padding: 20px; margin: 20px 0; border-left: 5px solid #29c5e6; font-style: italic; text-align: center;">
        <p style="font-size: 1.2rem; margin-bottom: 10px;">"Наша база отдыха - это идеальное место для полноценного отдыха от городской суеты."</p>
        <cite style="color: #666;">Директор базы отдыха</cite>
    </blockquote>
    
    <p style="text-align: center; font-size: 1.1rem; margin: 20px 0; line-height: 1.8;">
        База отдыха "Радужный" расположена в живописном месте Московской области. 
        Мы предлагаем комфортное проживание в уютных коттеджах, баню, рыбалку, 
        прогулки на лодке и многое другое.
    </p>
    
    <h2 class="page-title">Наши услуги</h2>
    <div class="services-grid">
        <div class="service-card">
            <h3>Проживание</h3>
            <p>Коттеджи на 2-6 человек с удобствами</p>
        </div>
        <div class="service-card">
            <h3>Питание</h3>
            <p>Кафе на территории базы отдыха</p>
        </div>
        <div class="service-card">
            <h3>Развлечения</h3>
            <p>Баня, рыбалка, прогулки на лодке</p>
        </div>
        <div class="service-card">
            <h3>Спорт и отдых</h3>
            <p>Велосипеды, волейбол, настольные игры</p>
        </div>
        <div class="service-card">
            <h3>Организация мероприятий</h3>
            <p>Свадьбы, корпоративы, дни рождения</p>
        </div>
        <div class="service-card">
            <h3>Прокат</h3>
            <p>Лодки, велосипеды, снасти для рыбалки</p>
        </div>
    </div>
    
    <h2 class="page-title">Популярные номера</h2>
    <div class="rooms-grid">
        <div class="room-card">
            <img src="images/sample.png" alt="Коттедж Люкс">
            <div class="room-card-content">
                <h3>Коттедж Люкс</h3>
                <p>До 6 человек, 2 спальни, кухня, санузел</p>
                <div class="price">от 5000 ₽/сутки</div>
            </div>
        </div>
        <div class="room-card">
            <img src="images/sample.png" alt="Стандартный коттедж">
            <div class="room-card-content">
                <h3>Стандартный коттедж</h3>
                <p>До 4 человек, 1 спальня, мини-кухня</p>
                <div class="price">от 3500 ₽/сутки</div>
            </div>
        </div>
        <div class="room-card">
            <img src="images/sample.png" alt="Мини-коттедж">
            <div class="room-card-content">
                <h3>Мини-коттедж</h3>
                <p>До 2 человек, 1 комната, мини-кухня</p>
                <div class="price">от 2500 ₽/сутки</div>
            </div>
        </div>
    </div>
    
    <div class="booking-form">
        <h3>Забронировать номер</h3>
        <form method="POST" action="process_booking.php">
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Ваше имя *</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Телефон *</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="room_type">Тип номера *</label>
                    <select id="room_type" name="room_type" required>
                        <option value="">Выберите тип номера</option>
                        <option value="lux">Коттедж Люкс</option>
                        <option value="standard">Стандартный коттедж</option>
                        <option value="mini">Мини-коттедж</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="check_in">Дата заезда *</label>
                    <input type="date" id="check_in" name="check_in" required>
                </div>
                <div class="form-group">
                    <label for="check_out">Дата выезда *</label>
                    <input type="date" id="check_out" name="check_out" required>
                </div>
            </div>
            <div class="form-group">
                <label for="message">Дополнительные пожелания</label>
                <textarea id="message" name="message" rows="3"></textarea>
            </div>
            <button type="submit" class="submit-btn">Забронировать</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>