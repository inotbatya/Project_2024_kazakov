<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$page_title = "Управление коттеджами - Админ-панель";
include '../includes/header.php';

require_once '../includes/db.php';
require_once '../includes/Cottage.php';

$database = new Database();
$db = $database->getConnection();
$cottage = new Cottage($db);

// Обработка форм
if ($_POST) {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'create') {
            $cottage->title = $_POST['title'];
            $cottage->description = $_POST['description'];
            $cottage->max_guests = $_POST['max_guests'];
            $cottage->price_per_night = $_POST['price_per_night'];
            $cottage->bedrooms = $_POST['bedrooms'];
            $cottage->amenities = $_POST['amenities'];
            $cottage->image = $_POST['image'];
            $cottage->status = $_POST['status'];
            
            $cottage->create();
        } elseif ($_POST['action'] == 'update') {
            $cottage->id = $_POST['id'];
            $cottage->title = $_POST['title'];
            $cottage->description = $_POST['description'];
            $cottage->max_guests = $_POST['max_guests'];
            $cottage->price_per_night = $_POST['price_per_night'];
            $cottage->bedrooms = $_POST['bedrooms'];
            $cottage->amenities = $_POST['amenities'];
            $cottage->image = $_POST['image'];
            $cottage->status = $_POST['status'];
            
            $cottage->update();
        } elseif ($_POST['action'] == 'delete') {
            $cottage->id = $_POST['id'];
            $cottage->delete();
        }
    }
}

$stmt = $cottage->read();
$cottages = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="admin-container">
        <header class="admin-header">
            <div class="admin-logo">Админ-панель</div>
            <nav class="admin-nav">
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="cottages.php">Коттеджи</a></li>
                    <li><a href="bookings.php">Бронирования</a></li>
                    <li><a href="services.php">Услуги</a></li>
                    <li><a href="gallery.php">Галерея</a></li>
                    <li><a href="reviews.php">Отзывы</a></li>
                    <li><a href="contacts.php">Сообщения</a></li>
                    <li><a href="logout.php">Выход</a></li>
                </ul>
            </nav>
        </header>
        
        <div class="admin-content">
            <h1 class="admin-page-title">Управление коттеджами</h1>
            
            <div class="form-container">
                <h3>Добавить новый коттедж</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="create">
                    <div class="form-group">
                        <label for="title">Название</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Описание</label>
                        <textarea id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="max_guests">Макс. гостей</label>
                        <input type="number" id="max_guests" name="max_guests" required>
                    </div>
                    <div class="form-group">
                        <label for="price_per_night">Цена за ночь</label>
                        <input type="number" id="price_per_night" name="price_per_night" required step="0.01">
                    </div>
                    <div class="form-group">
                        <label for="bedrooms">Количество спален</label>
                        <input type="number" id="bedrooms" name="bedrooms">
                    </div>
                    <div class="form-group">
                        <label for="amenities">Удобства</label>
                        <textarea id="amenities" name="amenities" rows="2"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="image">Изображение</label>
                        <input type="text" id="image" name="image">
                    </div>
                    <div class="form-group">
                        <label for="status">Статус</label>
                        <select id="status" name="status">
                            <option value="active">Активный</option>
                            <option value="inactive">Неактивный</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Создать коттедж</button>
                    </div>
                </form>
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Макс. гостей</th>
                            <th>Цена за ночь</th>
                            <th>Спальни</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($cottages as $row): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo $row['max_guests']; ?></td>
                            <td><?php echo number_format($row['price_per_night'], 0, '', ' '); ?> ₽</td>
                            <td><?php echo $row['bedrooms']; ?></td>
                            <td><span class="status-<?php echo $row['status']; ?>"><?php echo $row['status']; ?></span></td>
                            <td>
                                <a href="#" class="btn btn-warning" onclick="editCottage(<?php echo $row['id']; ?>, '<?php echo addslashes($row['title']); ?>', '<?php echo addslashes($row['description']); ?>', <?php echo $row['max_guests']; ?>, <?php echo $row['price_per_night']; ?>, <?php echo $row['bedrooms']; ?>, '<?php echo addslashes($row['amenities']); ?>', '<?php echo addslashes($row['image']); ?>', '<?php echo $row['status']; ?>')">Редактировать</a>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Удалить коттедж?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    function editCottage(id, title, description, max_guests, price_per_night, bedrooms, amenities, image, status) {
        document.querySelector('input[name="action"]').value = 'update';
        document.querySelector('input[name="id"]').value = id;
        document.querySelector('input[name="title"]').value = title;
        document.querySelector('textarea[name="description"]').value = description;
        document.querySelector('input[name="max_guests"]').value = max_guests;
        document.querySelector('input[name="price_per_night"]').value = price_per_night;
        document.querySelector('input[name="bedrooms"]').value = bedrooms;
        document.querySelector('textarea[name="amenities"]').value = amenities;
        document.querySelector('input[name="image"]').value = image;
        document.querySelector('select[name="status"]').value = status;
        
        document.querySelector('.form-container h3').textContent = 'Редактировать коттедж';
        document.querySelector('.form-container button[type="submit"]').textContent = 'Обновить коттедж';
    }
    </script>
</body>
</html>