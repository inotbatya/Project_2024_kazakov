<?php
session_start();

// Подключение к БД
$pdo = new PDO("mysql:host=localhost;dbname=driving_school;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Проверка, вошёл ли админ
function isAdmin() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

if (!isAdmin()) {
    header('Location: login.php');
    exit();
}
?>