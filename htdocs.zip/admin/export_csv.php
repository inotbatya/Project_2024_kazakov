<?php
require_once 'config.php';

$table = $_GET['table'] ?? 'students';

if ($table === 'students') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=students.csv');

    $output = fopen('php://output', 'w');

    // Добавляем BOM для корректного открытия в Excel
    fwrite($output, "\xEF\xBB\xBF");

    fputcsv($output, ['ID', 'Имя', 'Email', 'Телефон', 'Курс', 'Инструктор']);

    $stmt = $pdo->query("
        SELECT s.id, s.name, s.email, s.phone, c.title as course_title, i.name as instructor_name
        FROM students s
        LEFT JOIN courses c ON s.course_id = c.id
        LEFT JOIN instructors i ON s.instructor_id = i.id
    ");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['id'],
            $row['name'],
            $row['email'],
            $row['phone'],
            $row['course_title'] ?? 'Не выбран',
            $row['instructor_name'] ?? 'Не назначен'
        ]);
    }
} elseif ($table === 'instructors') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=instructors.csv');

    $output = fopen('php://output', 'w');

    // Добавляем BOM
    fwrite($output, "\xEF\xBB\xBF");

    fputcsv($output, ['ID', 'Имя', 'Стаж (лет)', 'Категории', 'Описание']);

    $stmt = $pdo->query("SELECT id, name, experience_years, categories, bio FROM instructors");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['id'],
            $row['name'],
            $row['experience_years'],
            $row['categories'],
            $row['bio']
        ]);
    }
}

fclose($output);
exit();
?>