<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Наши курсы — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link active" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link" href="courses_search.php">Поиск курсов в стране</a></li>
            <li class="nav-item"><a class="nav-link" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
            <li class="nav-item">
              <a class="nav-link btn btn-outline-light ms-2" href="dashboard.php">Личный кабинет</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент -->
  <main class="flex-grow-1">
    <section class="py-5">
      <div class="container">
        <h1 class="text-center mb-4">Наши курсы вождения</h1>
        <p class="text-center text-muted mb-5">Выберите подходящую программу обучения</p>

        <!-- Карточки курсов -->
        <div class="row g-4">
          <!-- Курс 1 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Категория+B" class="card-img-top" alt="Категория B">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Категория B</h5>
                <p class="card-text">Обучение вождению легковых автомобилей. Включает теорию, практику и подготовку к экзаменам.</p>
                <ul class="list-unstyled">
                  <li>✅ 40 часов теории</li>
                  <li>✅ 28 часов практики</li>
                  <li>✅ Гарантия сдачи экзамена</li>
                  <li>✅ Современные автомобили</li>
                </ul>
                <p class="fw-bold mt-auto">от 25 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>

          <!-- Курс 2 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Категория+A" class="card-img-top" alt="Категория A">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Категория A</h5>
                <p class="card-text">Обучение вождению мотоциклов и мопедов. Теория + практика на закрытой площадке.</p>
                <ul class="list-unstyled">
                  <li>✅ 24 часа теории</li>
                  <li>✅ 16 часов практики</li>
                  <li>✅ Безопасность и манёвры</li>
                  <li>✅ Инструкторы с опытом</li>
                </ul>
                <p class="fw-bold mt-auto">от 20 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>

          <!-- Курс 3 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Интенсив" class="card-img-top" alt="Интенсив">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Интенсив-курс</h5>
                <p class="card-text">Быстрое обучение за 2 недели. Идеально для занятых людей, которые хотят сдать экзамен как можно скорее.</p>
                <ul class="list-unstyled">
                  <li>✅ Утром и вечером</li>
                  <li>✅ 2 недели интенсивной практики</li>
                  <li>✅ Ускоренная теория</li>
                  <li>✅ Гарантия результата</li>
                </ul>
                <p class="fw-bold mt-auto">от 35 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>

          <!-- Курс 4 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Категория+C" class="card-img-top" alt="Категория C">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Категория C</h5>
                <p class="card-text">Обучение управлению грузовыми автомобилями. Подходит для тех, кто хочет работать дальнобойщиком.</p>
                <ul class="list-unstyled">
                  <li>✅ 56 часов теории</li>
                  <li>✅ 36 часов практики</li>
                  <li>✅ Обучение на спецтехнике</li>
                  <li>✅ Поддержка после курса</li>
                </ul>
                <p class="fw-bold mt-auto">от 40 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>

          <!-- Курс 5 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Повышение+квалификации" class="card-img-top" alt="Повышение квалификации">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Повышение квалификации</h5>
                <p class="card-text">Для водителей с опытом. Актуализация знаний ПДД и отработка навыков безопасного вождения.</p>
                <ul class="list-unstyled">
                  <li>✅ 8 часов практики</li>
                  <li>✅ Обновление знаний ПДД</li>
                  <li>✅ Скидки для постоянных клиентов</li>
                  <li>✅ Сертификат по окончании</li>
                </ul>
                <p class="fw-bold mt-auto">от 10 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>

          <!-- Курс 6 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow">
              <img src="https://placehold.co/600x400?text=Дополнительные+услуги" class="card-img-top" alt="Дополнительные услуги">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title">Дополнительные услуги</h5>
                <p class="card-text">Подготовка к экзаменам, вождение с инструктором, оформление документов и многое другое.</p>
                <ul class="list-unstyled">
                  <li>✅ Подача документов</li>
                  <li>✅ Вождение с инструктором</li>
                  <li>✅ Помощь в сдаче экзаменов</li>
                  <li>✅ Оформление водительского удостоверения</li>
                </ul>
                <p class="fw-bold mt-auto">от 5 000 ₽</p>
                <a href="booking.php" class="btn btn-primary mt-3">Записаться</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; 2025 DrivePro. Все права защищены.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>