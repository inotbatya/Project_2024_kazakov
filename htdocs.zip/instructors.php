<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Наши инструкторы — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link active" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
            <li class="nav-item">
              <a class="nav-link btn btn-outline-light ms-2" href="dashboard.php">Личный кабинет</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент -->
  <main class="flex-grow-1">
    <section class="py-5">
      <div class="container">
        <h1 class="text-center mb-5">Наши инструкторы</h1>
        <p class="text-center text-muted mb-5">Профессионалы с многолетним стажем и высоким рейтингом</p>

        <div class="row g-4">
          <!-- Инструктор 1 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="img/placeholder_team.png" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Сергей Петров">
              <div class="card-body">
                <h5 class="card-title">Сергей Петров</h5>
                <p class="card-text">Стаж вождения: 15 лет</p>
                <p class="text-muted">Категории: B, C</p>
                <p class="text-success fw-bold">98% учеников сдают с первого раза</p>
              </div>
            </div>
          </div>

          <!-- Инструктор 2 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="img/placeholder_team.png" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Анна Смирнова">
              <div class="card-body">
                <h5 class="card-title">Анна Смирнова</h5>
                <p class="card-text">Стаж вождения: 12 лет</p>
                <p class="text-muted">Категории: A, B</p>
                <p class="text-success fw-bold">Отличное понимание для новичков</p>
              </div>
            </div>
          </div>

          <!-- Инструктор 3 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="img/placeholder_team.png" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Дмитрий Волков">
              <div class="card-body">
                <h5 class="card-title">Дмитрий Волков</h5>
                <p class="card-text">Стаж вождения: 10 лет</p>
                <p class="text-muted">Категории: B</p>
                <p class="text-success fw-bold">Специализация — экстремальное вождение</p>
              </div>
            </div>
          </div>

          <!-- Инструктор 4 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="img/placeholder_team.png" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Елена Козлова">
              <div class="card-body">
                <h5 class="card-title">Елена Козлова</h5>
                <p class="card-text">Стаж вождения: 8 лет</p>
                <p class="text-muted">Категории: A, B</p>
                <p class="text-success fw-bold">Особое внимание ПДД и теории</p>
              </div>
            </div>
          </div>

          <!-- Инструктор 5 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="img/placeholder_team.png" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Игорь Морозов">
              <div class="card-body">
                <h5 class="card-title">Игорь Морозов</h5>
                <p class="card-text">Стаж вождения: 20 лет</p>
                <p class="text-muted">Категории: B, C, D</p>
                <p class="text-success fw-bold">Эксперт по сложным маршрутам</p>
              </div>
            </div>
          </div>

          <!-- Инструктор 6 -->
          <div class="col-md-6 col-lg-4">
            <div class="card h-100 text-center shadow">
              <img src="https://placehold.co/300x300?text=Ольга+Лебедева" class="card-img-top rounded-circle mx-auto" style="width: 150px; height: 150px; object-fit: cover;" alt="Ольга Лебедева">
              <div class="card-body">
                <h5 class="card-title">Ольга Лебедева</h5>
                <p class="card-text">Стаж вождения: 9 лет</p>
                <p class="text-muted">Категории: B</p>
                <p class="text-success fw-bold">Пациентный подход к каждому ученику</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; 2025 DrivePro. Все права защищены.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>