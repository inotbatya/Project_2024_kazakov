<?php
// Подключение к базе данных
$pdo = new PDO("mysql:host=localhost;dbname=driving_school;charset=utf8", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Если форма отправлена
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $course = $_POST['course'];
    $instructor = $_POST['instructor'];

    $stmt = $pdo->prepare("INSERT INTO bookings (name, phone, email, course, instructor, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$name, $phone, $email, $course, $instructor]);

    $success = "Заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.";
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Записаться на обучение — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link active" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
            <li class="nav-item">
              <a class="nav-link btn btn-outline-light ms-2" href="dashboard.php">Личный кабинет</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент -->
  <main class="flex-grow-1">
    <section class="py-5">
      <div class="container">
        <h1 class="text-center mb-4">Записаться на обучение</h1>
        <p class="text-center text-muted mb-5">Заполните форму и мы свяжемся с вами для уточнения деталей</p>

        <?php if (isset($success)): ?>
          <div class="alert alert-success">
            <?= htmlspecialchars($success) ?>
          </div>
        <?php endif; ?>

        <div class="row justify-content-center">
          <div class="col-md-8">
            <form method="POST">
              <div class="mb-3">
                <label for="name" class="form-label">Ваше имя</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>

              <div class="mb-3">
                <label for="phone" class="form-label">Телефон</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
              </div>

              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>

              <div class="mb-3">
                <label for="course" class="form-label">Выберите курс</label>
                <select class="form-select" id="course" name="course" required>
                  <option value="">-- Выберите курс --</option>
                  <option value="Категория B">Категория B (легковые)</option>
                  <option value="Категория A">Категория A (мотоциклы)</option>
                  <option value="Категория C">Категория C (грузовики)</option>
                  <option value="Интенсив">Интенсив-курс</option>
                  <option value="Повышение квалификации">Повышение квалификации</option>
                  <option value="Дополнительные услуги">Дополнительные услуги</option>
                </select>
              </div>

              <div class="mb-3">
                <label for="instructor" class="form-label">Предпочтительный инструктор</label>
                <select class="form-select" id="instructor" name="instructor">
                  <option value="">-- Не важно --</option>
                  <option value="Сергей Петров">Сергей Петров</option>
                  <option value="Анна Смирнова">Анна Смирнова</option>
                  <option value="Дмитрий Волков">Дмитрий Волков</option>
                  <option value="Елена Козлова">Елена Козлова</option>
                  <option value="Игорь Морозов">Игорь Морозов</option>
                  <option value="Ольга Лебедева">Ольга Лебедева</option>
                </select>
              </div>

              <button type="submit" class="btn btn-primary w-100">Отправить заявку</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; 2025 DrivePro. Все права защищены.</p>
    </div>
  </footer>

</body>
</html>