<?php
session_start();

// Подключение к базе данных
$pdo = new PDO("mysql:host=localhost;dbname=driving_school;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Проверка, является ли пользователь студентом
    $stmt = $pdo->prepare("SELECT id, name, password FROM students WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role'] = 'student';
        header('Location: dashboard.php');
        exit();
    } else {
        $error = "Неверный email или пароль.";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Вход — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент -->
  <main class="flex-grow-1 d-flex align-items-center justify-content-center py-5">
    <div class="col-md-6 col-lg-4">
      <div class="card shadow">
        <div class="card-header text-center bg-primary text-white">
          <h4>Вход в личный кабинет</h4>
        </div>
        <div class="card-body">
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <form method="POST">
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <div class="mb-3">
              <label for="password" class="form-label">Пароль</label>
              <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="remember">
              <label class="form-check-label" for="remember">Запомнить меня</label>
            </div>

            <button type="submit" class="btn btn-primary w-100">Войти</button>
          </form>

          <div class="text-center mt-3">
            <p>Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
            <p><a href="forgot_password.php">Забыли пароль?</a></p>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; 2025 DrivePro. Все права защищены.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>