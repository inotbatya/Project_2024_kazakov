<?php
$page_title = "Номера - База отдыха 'Радужный'";
$page_description = "Коттеджи и номера в базе отдыха 'Радужный': люкс, стандарт, мини-коттеджи. Фото, описание, цены, бронирование.";
include 'includes/header.php';
?>

<div class="main-content">
    <h1 class="page-title">Наши коттеджи</h1>
    
    <p style="text-align: center; font-size: 1.1rem; margin: 20px 0; line-height: 1.8; color: #666;">
        В базе отдыха "Радужный" представлены различные варианты проживания: 
        от уютных мини-коттеджей до комфортабельных коттеджей класса люкс. 
        Все коттеджи выполнены в едином стиле, уютно обставлены и оборудованы 
        всем необходимым для комфортного отдыха.
    </p>
    
    <div class="rooms-grid">
        <div class="room-card">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div class="room-card-content">
                <h3>Коттедж Люкс</h3>
                <p>До 6 человек, 2 спальни, кухня, санузел</p>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Общая площадь: 60 м²</li>
                    <li>2 спальни (2 двуспальные кровати)</li>
                    <li>Современная кухня с техникой</li>
                    <li>Совмещенный санузел</li>
                    <li>Телевизор, Wi-Fi</li>
                    <li>Балкон с видом на озеро</li>
                </ul>
                <div class="price">от 5000 ₽/сутки</div>
            </div>
        </div>
        
        <div class="room-card">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div class="room-card-content">
                <h3>Стандартный коттедж</h3>
                <p>До 4 человек, 1 спальня, мини-кухня</p>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Общая площадь: 35 м²</li>
                    <li>1 спальня (2 односпальные кровати)</li>
                    <li>Мини-кухня с техникой</li>
                    <li>Отдельный санузел</li>
                    <li>Телевизор, Wi-Fi</li>
                    <li>Терраса</li>
                </ul>
                <div class="price">от 3500 ₽/сутки</div>
            </div>
        </div>
        
        <div class="room-card">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div class="room-card-content">
                <h3>Мини-коттедж</h3>
                <p>До 2 человек, 1 комната, мини-кухня</p>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Общая площадь: 20 м²</li>
                    <li>1 комната (двуспальная кровать)</li>
                    <li>Мини-кухня</li>
                    <li>Отдельный санузел</li>
                    <li>Wi-Fi</li>
                    <li>Маленькая терраса</li>
                </ul>
                <div class="price">от 2500 ₽/сутки</div>
            </div>
        </div>
        
        <div class="room-card">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div class="room-card-content">
                <h3>Коттедж с баней</h3>
                <p>До 8 человек, 3 спальни, собственная баня</p>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Общая площадь: 80 м²</li>
                    <li>3 спальни (2 двуспальные + 2 односпальные)</li>
                    <li>Просторная кухня-гостиная</li>
                    <li>2 санузла</li>
                    <li>Русская баня на дровах</li>
                    <li>Терраса с мангалом</li>
                </ul>
                <div class="price">от 7000 ₽/сутки</div>
            </div>
        </div>
    </div>
    
    <div style="background: linear-gradient(135deg, #0097a7, #006064); color: white; padding: 30px; border-radius: 15px; margin: 40px 0; text-align: center;">
        <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 20px; font-size: 1.8rem;">Правила бронирования</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; text-align: left;">
            <div>
                <h4 style="color: #4dd0e1; margin-bottom: 10px;">Стоимость проживания</h4>
                <ul style="list-style: none; padding: 0;">
                    <li>Понедельник-четверг: базовая цена</li>
                    <li>Пятница-воскресенье: +20% к базовой цене</li>
                    <li>Праздничные дни: +30% к базовой цене</li>
                    <li>Дети до 3 лет: бесплатно</li>
                    <li>Дети 3-12 лет: -50% от стоимости</li>
                </ul>
            </div>
            <div>
                <h4 style="color: #4dd0e1; margin-bottom: 10px;">Условия бронирования</h4>
                <ul style="list-style: none; padding: 0;">
                    <li>Предоплата 50% при бронировании</li>
                    <li>Возврат за 7 дней до заезда: 100%</li>
                    <li>Возврат за 3-7 дней: 50%</li>
                    <li>Позднее: не возвращается</li>
                    <li>Заселение: после 14:00</li>
                    <li>Выселение: до 12:00</li>
                </ul>
            </div>
        </div>
    </div>
    
    <h2 class="page-title" style="font-size: 2rem;">Дополнительные услуги</h2>
    
    <div class="services-grid">
        <div class="service-card">
            <h3>Телевизор</h3>
            <p>500 ₽ / сутки</p>
        </div>
        <div class="service-card">
            <h3>Wi-Fi</h3>
            <p>Бесплатно</p>
        </div>
        <div class="service-card">
            <h3>Питание</h3>
            <p>По меню</p>
        </div>
        <div class="service-card">
            <h3>Уборка</h3>
            <p>300 ₽ / раз</p>
        </div>
    </div>
    
    <div class="booking-form">
        <h3>Забронировать коттедж</h3>
        <form method="POST" action="process_booking.php">
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Ваше имя *</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Телефон *</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="room_type">Тип коттеджа *</label>
                    <select id="room_type" name="room_type" required>
                        <option value="">Выберите тип коттеджа</option>
                        <option value="lux">Коттедж Люкс</option>
                        <option value="standard">Стандартный коттедж</option>
                        <option value="mini">Мини-коттедж</option>
                        <option value="bath">Коттедж с баней</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="check_in">Дата заезда *</label>
                    <input type="date" id="check_in" name="check_in" required>
                </div>
                <div class="form-group">
                    <label for="check_out">Дата выезда *</label>
                    <input type="date" id="check_out" name="check_out" required>
                </div>
                <div class="form-group">
                    <label for="guests">Количество гостей</label>
                    <select id="guests" name="guests">
                        <option value="1">1 человек</option>
                        <option value="2">2 человека</option>
                        <option value="3">3 человека</option>
                        <option value="4">4 человека</option>
                        <option value="5">5 человек</option>
                        <option value="6">6 человек</option>
                        <option value="7">7 человек</option>
                        <option value="8">8 человек</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="special_requests">Особые пожелания</label>
                    <input type="text" id="special_requests" name="special_requests">
                </div>
            </div>
            <div class="form-group">
                <label for="message">Дополнительные пожелания</label>
                <textarea id="message" name="message" rows="3"></textarea>
            </div>
            <button type="submit" class="submit-btn">Забронировать</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>