<?php
$page_title = "О нас - База отдыха 'Радужный'";
$page_description = "Информация о базе отдыха 'Радужный': история создания, достижения, команда, философия отдыха.";
include 'includes/header.php';
?>

<div class="main-content">
    <h1 class="page-title">О нашей базе отдыха</h1>
    
    <div style="background: linear-gradient(135deg, #e0f7fa, #b2ebf2); padding: 30px; border-radius: 15px; margin: 30px 0; border-left: 5px solid #0097a7;">
        <p style="font-size: 1.2rem; line-height: 1.8; color: #333; text-align: center;">
            База отдыха "Радужный" - это оазис спокойствия и уюта в окружении живописной природы. 
            Мы создали это место для тех, кто хочет отдохнуть душой и телом, 
            насладиться тишиной и свежим воздухом.
        </p>
    </div>
    
    <div class="services-grid">
        <div class="service-card" style="text-align: left;">
            <h3 style="text-align: center;">Наша история</h3>
            <p style="text-align: justify;">
                База отдыха "Радужный" была основана в 2010 году в живописном месте 
                Московской области, недалеко от озера. С самого начала мы стремились 
                создать место, где каждый гость чувствует себя как дома, окруженный 
                заботой, вниманием и красотой природы.
            </p>
            <p style="text-align: justify; margin-top: 15px;">
                За годы работы мы накопили богатый опыт в организации отдыха, 
                постоянно совершенствуем качество предоставляемых услуг и 
                расширяем спектр возможностей для наших гостей.
            </p>
        </div>
        <div class="service-card" style="text-align: left;">
            <h3 style="text-align: center;">Наши достижения</h3>
            <ul style="list-style: none; padding: 0; margin: 15px 0;">
                <li style="margin: 10px 0; padding-left: 25px; position: relative;">
                    <span style="position: absolute; left: 0; color: #0097a7; font-weight: bold;">✓</span>
                    Более 10 лет успешной работы
                </li>
                <li style="margin: 10px 0; padding-left: 25px; position: relative;">
                    <span style="position: absolute; left: 0; color: #0097a7; font-weight: bold;">✓</span>
                    Более 5000 довольных клиентов
                </li>
                <li style="margin: 10px 0; padding-left: 25px; position: relative;">
                    <span style="position: absolute; left: 0; color: #0097a7; font-weight: bold;">✓</span>
                    Лучшая база отдыха региона (2022)
                </li>
                <li style="margin: 10px 0; padding-left: 25px; position: relative;">
                    <span style="position: absolute; left: 0; color: #0097a7; font-weight: bold;">✓</span>
                    Сертификаты качества от туристических ассоциаций
                </li>
                <li style="margin: 10px 0; padding-left: 25px; position: relative;">
                    <span style="position: absolute; left: 0; color: #0097a7; font-weight: bold;">✓</span>
                    95% повторных клиентов
                </li>
            </ul>
        </div>
    </div>
    
    <h2 class="page-title" style="font-size: 2rem;">Наши принципы</h2>
    
    <div class="services-grid">
        <div class="service-card">
            <h3>Качество</h3>
            <p>Мы стремимся к высокому качеству во всем - от обслуживания до 
               инфраструктуры и природной среды.</p>
        </div>
        <div class="service-card">
            <h3>Безопасность</h3>
            <p>Безопасность наших гостей - наш приоритет. Охраняемая территория 
               и профессиональный персонал.</p>
        </div>
        <div class="service-card">
            <h3>Экология</h3>
            <p>Мы заботимся о природе и стараемся минимизировать воздействие 
               на окружающую среду.</p>
        </div>
    </div>
    
    <h2 class="page-title" style="font-size: 2rem;">Наши сотрудники</h2>
    
    <div style="background: white; padding: 30px; border-radius: 15px; margin: 30px 0; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
        <div style="display: flex; flex-wrap: wrap; gap: 30px; justify-content: center;">
            <div style="text-align: center; flex: 0 0 200px;">
                <div style="width: 150px; height: 150px; background: #e0f7fa; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: #0097a7;">
                    👨
                </div>
                <h4 style="color: #0097a7; margin: 10px 0;">Александр Петров</h4>
                <p style="color: #666;">Директор</p>
            </div>
            <div style="text-align: center; flex: 0 0 200px;">
                <div style="width: 150px; height: 150px; background: #e0f7fa; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: #0097a7;">
                    👩
                </div>
                <h4 style="color: #0097a7; margin: 10px 0;">Мария Сидорова</h4>
                <p style="color: #666;">Администратор</p>
            </div>
            <div style="text-align: center; flex: 0 0 200px;">
                <div style="width: 150px; height: 150px; background: #e0f7fa; border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: #0097a7;">
                    👨
                </div>
                <h4 style="color: #0097a7; margin: 10px 0;">Дмитрий Иванов</h4>
                <p style="color: #666;">Инструктор по вождению</p>
            </div>
        </div>
    </div>
    
    <div style="background: linear-gradient(135deg, #0097a7, #006064); color: white; padding: 40px; border-radius: 15px; margin: 40px 0; text-align: center;">
        <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 20px; font-size: 2rem;">Наша миссия</h3>
        <p style="font-size: 1.2rem; line-height: 1.6; max-width: 800px; margin: 0 auto;">
            Создавать комфортные условия для полноценного отдыха и восстановления сил, 
            предоставить возможность отдохнуть от городской суеты и насладиться природой, 
            сделать отдых наших гостей незабываемым и полезным для здоровья.
        </p>
    </div>
    
    <div class="booking-form">
        <h3>Посетить нашу базу отдыха</h3>
        <form method="POST" action="process_booking.php">
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Ваше имя *</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Телефон *</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="room_type">Тип номера</label>
                    <select id="room_type" name="room_type">
                        <option value="">Выберите тип номера</option>
                        <option value="lux">Коттедж Люкс</option>
                        <option value="standard">Стандартный коттедж</option>
                        <option value="mini">Мини-коттедж</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="check_in">Дата заезда *</label>
                    <input type="date" id="check_in" name="check_in" required>
                </div>
                <div class="form-group">
                    <label for="check_out">Дата выезда *</label>
                    <input type="date" id="check_out" name="check_out" required>
                </div>
            </div>
            <div class="form-group">
                <label for="message">Дополнительные пожелания</label>
                <textarea id="message" name="message" rows="3"></textarea>
            </div>
            <button type="submit" class="submit-btn">Забронировать</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>