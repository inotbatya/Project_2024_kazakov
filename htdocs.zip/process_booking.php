<?php
require_once 'includes/functions.php';

if ($_POST) {
    $booking_data = array(
        'name' => sanitize_input($_POST['name']),
        'phone' => sanitize_input($_POST['phone']),
        'email' => validate_email($_POST['email']) ? sanitize_input($_POST['email']) : '',
        'room_type' => sanitize_input($_POST['room_type']),
        'check_in' => sanitize_input($_POST['check_in']),
        'check_out' => sanitize_input($_POST['check_out']),
        'guests' => isset($_POST['guests']) ? sanitize_input($_POST['guests']) : 1,
        'message' => sanitize_input($_POST['message'])
    );
    
    if (send_booking_request($booking_data)) {
        echo "<h2>Спасибо за бронирование, {$booking_data['name']}!</h2>";
        echo "<p>Мы свяжемся с вами по телефону {$booking_data['phone']}</p>";
        echo "<p><a href='/'>Вернуться на главную</a></p>";
    } else {
        echo "<h2>Ошибка при бронировании</h2>";
        echo "<p><a href='/'>Вернуться на главную</a></p>";
    }
} else {
    header('Location: /');
}
?>