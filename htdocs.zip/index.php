<?php
session_start();
$logged_in = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DrivePro — Автошкола с гарантией прохождения</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css" />
</head>
<body class="d-flex flex-column min-vh-100">

  <!-- Шапка сайта -->
  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
          <img src="img/auto-logo.png" alt="DrivePro Logo" height="80" class="rounded shadow">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu">
          <span class="navbar-toggler-icon"></span>
        </button>

                <div class="collapse navbar-collapse" id="mainMenu">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>
            <li class="nav-item"><a class="nav-link" href="courses.php">Курсы</a></li>
            <li class="nav-item"><a class="nav-link" href="instructors.php">Инструкторы</a></li>
            <li class="nav-item"><a class="nav-link" href="booking.php">Записаться</a></li>
            <li class="nav-item"><a class="nav-link" href="contacts.php">Контакты</a></li>
            <li class="nav-item">
              <a class="nav-link btn btn-outline-light ms-2" href="dashboard.php">Личный кабинет</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>

  <!-- Основной контент -->
  <main class="flex-grow-1">
    <!-- Герой-секция -->
    <section class="hero-section bg-primary text-white">
      <div class="container text-center">
        <h1 class="display-4 fw-bold">DrivePro</h1>
        <p class="lead">Научим водить безопасно и уверенно с 2012 года</p>
        <a href="booking.php" class="btn btn-light btn-lg mt-3">Записаться на обучение</a>
      </div>
    </section>

    <!-- Услуги -->
    <section class="py-5 bg-light">
      <div class="container">
        <h2 class="text-center mb-5">Наши курсы</h2>
        <div class="row g-4">
          <div class="col-md-4">
            <div class="card h-100">
              <img src="https://placehold.co/600x400?text=Категория+B" class="card-img-top" alt="Категория B">
              <div class="card-body">
                <h5 class="card-title">Категория B</h5>
                <p class="card-text">Обучение вождению на легковых автомобилях.</p>
                <p class="fw-bold">от 25 000 ₽</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card h-100">
              <img src="https://placehold.co/600x400?text=Категория+A" class="card-img-top" alt="Категория A">
              <div class="card-body">
                <h5 class="card-title">Категория A</h5>
                <p class="card-text">Обучение вождению мотоциклов и мопедов.</p>
                <p class="fw-bold">от 20 000 ₽</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card h-100">
              <img src="https://placehold.co/600x400?text=Интенсив" class="card-img-top" alt="Интенсив">
              <div class="card-body">
                <h5 class="card-title">Интенсив-курс</h5>
                <p class="card-text">Быстрое обучение за 2 недели с гарантией сдачи экзамена.</p>
                <p class="fw-bold">от 35 000 ₽</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Слайдер с отзывами -->
    <section class="py-5">
      <div class="container">
        <h2 class="text-center mb-5">Отзывы учеников</h2>
        <div class="slider-container position-relative">
          <div class="slider-track" id="sliderTrack">
            <div class="slider-item">
              <p>«Сдал с первого раза! Инструктор Сергей — настоящий профи.»</p>
              <small>— Мария, 21 год</small>
            </div>
            <div class="slider-item">
              <p>«Отличная подготовка к теории и практике. Спасибо за терпение!»</p>
              <small>— Алексей, 28 лет</small>
            </div>
            <div class="slider-item">
              <p>«После интенсива чувствую себя уверенно на дороге.»</p>
              <small>— Игорь, 32 года</small>
            </div>
          </div>
          <button class="slider-btn prev" onclick="moveSlide(-1)">‹</button>
          <button class="slider-btn next" onclick="moveSlide(1)">›</button>
        </div>
      </div>
    </section>
  </main>

  <!-- Подвал -->
  <footer class="bg-dark text-white py-4 mt-auto">
    <div class="container text-center">
      <p>г. Москва, ул. Автозаводская, д. 25</p>
      <p>Телефон: +7 (495) 987-65-43</p>
      <p>Email: info@drivepro.ru</p>
      <p>&copy; 2025 DrivePro. Все права защищены.</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/script.js"></script>
</body>
</html>