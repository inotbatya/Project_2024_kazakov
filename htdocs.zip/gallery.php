<?php
$page_title = "Галерея - База отдыха 'Радужный'";
$page_description = "Фотогалерея базы отдыха 'Радужный': коттеджи, природа, баня, рыбалка, мероприятия, отдых на природе.";
include 'includes/header.php';
?>

<div class="main-content">
    <h1 class="page-title">Фотогалерея</h1>
    
    <p style="text-align: center; font-size: 1.1rem; margin: 20px 0; line-height: 1.8; color: #666;">
        Посмотрите фотографии нашей базы отдыха "Радужный". 
        Здесь вы найдете изображения коттеджей, природы, зон отдыха и моментов с отдыхающих гостей.
    </p>
    
    <div style="margin: 30px 0;">
        <h2 style="text-align: center; color: #0097a7; margin-bottom: 20px;">Категории фото</h2>
        <div style="display: flex; justify-content: center; flex-wrap: wrap; gap: 10px; margin-bottom: 30px;">
            <button onclick="filterGallery('all')" style="background: #0097a7; color: white; padding: 10px 20px; border: none; border-radius: 25px; cursor: pointer; margin: 5px;">Все</button>
            <button onclick="filterGallery('rooms')" style="background: #e0f7fa; color: #0097a7; padding: 10px 20px; border: 1px solid #0097a7; border-radius: 25px; cursor: pointer; margin: 5px;">Коттеджи</button>
            <button onclick="filterGallery('nature')" style="background: #e0f7fa; color: #0097a7; padding: 10px 20px; border: 1px solid #0097a7; border-radius: 25px; cursor: pointer; margin: 5px;">Природа</button>
            <button onclick="filterGallery('services')" style="background: #e0f7fa; color: #0097a7; padding: 10px 20px; border: 1px solid #0097a7; border-radius: 25px; cursor: pointer; margin: 5px;">Услуги</button>
            <button onclick="filterGallery('events')" style="background: #e0f7fa; color: #0097a7; padding: 10px 20px; border: 1px solid #0097a7; border-radius: 25px; cursor: pointer; margin: 5px;">Мероприятия</button>
        </div>
    </div>
    
    <div class="gallery-grid">
        <!-- Коттеджи -->
        <div class="gallery-item" data-category="rooms">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Коттедж Люкс</h4>
                <p>Комфортное проживание для 6 человек</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="rooms">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Стандартный коттедж</h4>
                <p>Комфортное проживание для 4 человек</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="rooms">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #e0f7fa, #b2ebf2); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏠
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Мини-коттедж</h4>
                <p>Уютное проживание для 2 человек</p>
            </div>
        </div>
        
        <!-- Природа -->
        <div class="gallery-item" data-category="nature">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #a7ffeb, #64ffda); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🌲
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Природа</h4>
                <p>Живописные пейзажи базы отдыха</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="nature">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #a7ffeb, #64ffda); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🌊
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Озеро</h4>
                <p>Купание и прогулки на лодке</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="nature">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #a7ffeb, #64ffda); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🌳
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Лес</h4>
                <p>Прогулки по живописным лесам</p>
            </div>
        </div>
        
        <!-- Услуги -->
        <div class="gallery-item" data-category="services">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #b2ebf2, #80deea); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏊
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Баня</h4>
                <p>Баня на дровах с парной</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="services">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #b2ebf2, #80deea); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🎣
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Рыбалка</h4>
                <p>Организованные рыбалки на озере</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="services">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #b2ebf2, #80deea); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🚣
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Лодки</h4>
                <p>Прогулки по озеру</p>
            </div>
        </div>
        
        <!-- Мероприятия -->
        <div class="gallery-item" data-category="events">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #bbdefb, #82b1ff); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🎉
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Корпоратив</h4>
                <p>Организация корпоративных мероприятий</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="events">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #bbdefb, #82b1ff); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                💒
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Свадьба</h4>
                <p>Свадьбы на природе</p>
            </div>
        </div>
        
        <div class="gallery-item" data-category="events">
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #bbdefb, #82b1ff); display: flex; align-items: center; justify-content: center; font-size: 3rem;">
                🏕️
            </div>
            <div style="padding: 15px; text-align: center; background: white;">
                <h4>Пикник</h4>
                <p>Отдых с семьей и друзьями</p>
            </div>
        </div>
    </div>
    
    <div style="background: white; padding: 40px; border-radius: 15px; margin: 40px 0; box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
        <h3 style="text-align: center; color: #0097a7; margin-bottom: 30px; font-size: 2rem;">Отзывы гостей</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;">
            <div style="background: #e0f7fa; padding: 20px; border-radius: 10px; border-left: 5px solid #0097a7;">
                <p style="font-style: italic; margin-bottom: 15px;">"Прекрасный отдых! Коттедж чистый, уютный, все необходимое есть. Баня отличная, природа красивая. Обязательно приедем снова!"</p>
                <div style="text-align: right;">
                    <strong>Анна Петрова</strong>
                    <div style="color: #0097a7; margin-top: 5px;">⭐⭐⭐⭐⭐</div>
                </div>
            </div>
            
            <div style="background: #e0f7fa; padding: 20px; border-radius: 10px; border-left: 5px solid #0097a7;">
                <p style="font-style: italic; margin-bottom: 15px;">"Отличное место для семейного отдыха. Дети в восторге от детской площадки, а взрослые от баньки. Рекомендуем всем!"</p>
                <div style="text-align: right;">
                    <strong>Михаил Сидоров</strong>
                    <div style="color: #0097a7; margin-top: 5px;">⭐⭐⭐⭐⭐</div>
                </div>
            </div>
            
            <div style="background: #e0f7fa; padding: 20px; border-radius: 10px; border-left: 5px solid #0097a7;">
                <p style="font-style: italic; margin-bottom: 15px;">"Замечательное место для отдыха от городской суеты. Природа, тишина, чистый воздух. Всем довольны!"</p>
                <div style="text-align: right;">
                    <strong>Елена Козлова</strong>
                    <div style="color: #0097a7; margin-top: 5px;">⭐⭐⭐⭐⭐</div>
                </div>
            </div>
        </div>
    </div>
    
    <div style="background: linear-gradient(135deg, #0097a7, #006064); color: white; padding: 30px; border-radius: 15px; margin: 40px 0; text-align: center;">
        <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 20px; font-size: 1.8rem;">Поделиться отдыхом</h3>
        <p style="margin-bottom: 20px; font-size: 1.1rem;">Отправьте нам свои фотографии с отдыха, и мы разместим их в нашей галерее!</p>
        <div style="display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
            <a href="mailto:photos@raduzhny.ru" style="background: rgba(255,255,255,0.2); color: white; padding: 12px 25px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; gap: 10px; transition: background 0.3s ease;">
                <span>📷</span> Прислать фотографии
            </a>
            <a href="https://instagram.com/raduzhny" style="background: rgba(255,255,255,0.2); color: white; padding: 12px 25px; border-radius: 8px; text-decoration: none; display: flex; align-items: center; gap: 10px; transition: background 0.3s ease;">
                <span>📱</span> Instagram
            </a>
        </div>
    </div>
</div>

<script>
function filterGallery(category) {
    const items = document.querySelectorAll('.gallery-item');
    
    items.forEach(item => {
        if (category === 'all' || item.getAttribute('data-category') === category) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
    
    // Обновляем стили кнопок
    const buttons = document.querySelectorAll('[onclick^="filterGallery"]');
    buttons.forEach(button => {
        if (button.textContent.includes(category) || (category === 'all' && button.textContent === 'Все')) {
            button.style.background = '#0097a7';
            button.style.color = 'white';
        } else {
            button.style.background = '#e0f7fa';
            button.style.color = '#0097a7';
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>