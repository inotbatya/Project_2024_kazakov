<?php
// Подключение к БД
$pdo = new PDO("mysql:host=localhost;dbname=driving_school;charset=utf8mb4", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Получение параметров поиска
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';

// Формирование запроса
$sql = "SELECT id, title, description, duration_weeks, price, category FROM courses WHERE 1=1";
$params = [];

if ($search) {
    $sql .= " AND (title LIKE ? OR description LIKE ? OR category LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}

if ($category) {
    $sql .= " AND category = ?";
    $params[] = $category;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Каталог курсов — DrivePro</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container">
    <h1 class="my-5 text-center">Каталог курсов</h1>

    <!-- Форма поиска -->
    <form method="GET" class="mb-4">
      <div class="row">
        <div class="col-md-6">
          <input type="text" name="search" class="form-control" placeholder="Поиск по названию, описанию..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-md-4">
          <select name="category" class="form-select">
            <option value="">Все категории</option>
            <option value="B" <?= $category === 'B' ? 'selected' : '' ?>>Категория B</option>
            <option value="A" <?= $category === 'A' ? 'selected' : '' ?>>Категория A</option>
            <option value="C" <?= $category === 'C' ? 'selected' : '' ?>>Категория C</option>
            <option value="D" <?= $category === 'D' ? 'selected' : '' ?>>Категория D</option>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100">Найти</button>
        </div>
      </div>
    </form>

    <!-- Результаты -->
    <div class="row">
      <?php if ($courses): ?>
        <?php foreach ($courses as $course): ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100 shadow">
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($course['title']) ?></h5>
                <p class="card-text"><?= htmlspecialchars($course['description']) ?></p>
                <p><strong>Длительность:</strong> <?= $course['duration_weeks'] ?> недель</p>
                <p><strong>Категория:</strong> <?= htmlspecialchars($course['category']) ?></p>
                <p class="fw-bold text-success"><?= number_format($course['price'], 0, '', ' ') ?> ₽</p>
              </div>
              <div class="card-footer">
                <a href="booking.php" class="btn btn-primary w-100">Записаться</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="col-12">
          <p class="text-center">Курсы не найдены.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>