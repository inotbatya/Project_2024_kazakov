<?php
$page_title = "Услуги - База отдыха 'Радужный'";
$page_description = "Услуги базы отдыха 'Радужный': проживание, баня, рыбалка, прокат лодок и велосипедов, организация мероприятий.";
include 'includes/header.php';
?>

<div class="main-content">
    <h1 class="page-title">Наши услуги</h1>
    
    <p style="text-align: center; font-size: 1.1rem; margin: 20px 0; line-height: 1.8; color: #666;">
        База отдыха "Радужный" предлагает широкий спектр услуг для комфортного и увлекательного отдыха на природе. 
        Наши услуги включают в себя проживание, питание, развлечения и организацию мероприятий.
    </p>
    
    <div class="services-grid">
        <div class="service-card">
            <h3>Проживание</h3>
            <p>Уютные коттеджи на 2-6 человек с современными удобствами, кухней, санузлом и мебелью. 
               Все коттеджи утеплены и оборудованы для круглогодичного проживания.</p>
        </div>
        <div class="service-card">
            <h3>Кафе на территории</h3>
            <p>Ресторан на территории базы отдыха предлагает разнообразное меню из свежих блюд 
               русской и европейской кухни. Все блюда готовятся из натуральных продуктов 
               местного производства.</p>
        </div>
        <div class="service-card">
            <h3>Баня</h3>
            <p>Русская баня на дровах с парной, комнатой отдыха и террасой. 
               Баня вмещает до 8 человек. Предоставляются веники, ароматические масла и полотенца.</p>
        </div>
        <div class="service-card">
            <h3>Рыбалка</h3>
            <p>Организация рыбалки на озере. Предоставляем снасти, катера и сопровождение. 
               Наши озера богаты карпом, щукой, окунем и другими видами рыб.</p>
        </div>
        <div class="service-card">
            <h3>Прокат лодок</h3>
            <p>Прокат моторных и весельных лодок. Возможность прогулок по озеру, 
               водных экскурсий и рыбалки. Лодки оснащены необходимыми спасательными средствами.</p>
        </div>
        <div class="service-card">
            <h3>Прокат велосипедов</h3>
            <p>Прокат горных и прогулочных велосипедов для прогулок по окрестностям. 
               Маршруты различной сложности. Велосипеды в хорошем состоянии, 
               с замками и шлемами.</p>
        </div>
        <div class="service-card">
            <h3>Спортивные площадки</h3>
            <p>Волейбольная, баскетбольная площадки, теннисный корт. Оборудование для 
               активного отдыха. Возможность организации соревнований и турниров.</p>
        </div>
        <div class="service-card">
            <h3>Детская площадка</h3>
            <p>Безопасная детская площадка с горками, качелями и другими аттракционами. 
               Площадка оборудована резиновым покрытием и находится под присмотром.</p>
        </div>
        <div class="service-card">
            <h3>Организация мероприятий</h3>
            <p>Проведение корпоративов, свадеб, дней рождения и других праздников. 
               Комплексное обслуживание: питание, развлечения, транспорт.</p>
        </div>
        <div class="service-card">
            <h3>Дополнительные услуги</h3>
            <p>Wi-Fi, охраняемая парковка, прачечная, услуги консьержа. 
               Все необходимое для комфортного отдыха.</p>
        </div>
    </div>
    
    <div style="background: linear-gradient(135deg, #0097a7, #006064); color: white; padding: 30px; border-radius: 15px; margin: 40px 0; text-align: center;">
        <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 15px;">Специальные предложения</h3>
        <p style="margin-bottom: 15px; font-size: 1.1rem;">При бронировании на 3 и более дней - скидка 15%</p>
        <p style="margin-bottom: 15px; font-size: 1.1rem;">Дети до 5 лет - бесплатно</p>
        <p style="font-size: 1.1rem;">Групповые скидки при заказе более 10 мест</p>
    </div>
    
    <div class="booking-form">
        <h3>Забронировать услугу</h3>
        <form method="POST" action="process_booking.php">
            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Ваше имя *</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Телефон *</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="service_type">Услуга *</label>
                    <select id="service_type" name="room_type" required>
                        <option value="">Выберите услугу</option>
                        <option value="lux">Коттедж Люкс</option>
                        <option value="standard">Стандартный коттедж</option>
                        <option value="mini">Мини-коттедж</option>
                        <option value="bath">Баня</option>
                        <option value="fishing">Рыбалка</option>
                        <option value="boats">Прокат лодок</option>
                        <option value="bikes">Прокат велосипедов</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="check_in">Дата *</label>
                    <input type="date" id="check_in" name="check_in" required>
                </div>
                <div class="form-group">
                    <label for="check_out">Дата окончания</label>
                    <input type="date" id="check_out" name="check_out">
                </div>
            </div>
            <div class="form-group">
                <label for="message">Дополнительные пожелания</label>
                <textarea id="message" name="message" rows="3"></textarea>
            </div>
            <button type="submit" class="submit-btn">Забронировать</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>