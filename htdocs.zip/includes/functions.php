<?php
require_once 'config.php';

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function send_booking_request($data) {
    global $db;
    
    $query = "INSERT INTO bookings (cottage_id, guest_name, guest_email, guest_phone, check_in, check_out, guests_count, special_requests, total_price, status) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
    $stmt = $db->prepare($query);
    
    $stmt->execute([
        $data['room_type'],
        $data['name'],
        $data['email'],
        $data['phone'],
        $data['check_in'],
        $data['check_out'],
        isset($data['guests']) ? $data['guests'] : 1,
        $data['message'],
        $data['total_price'] ?? 0
    ]);
    
    return true;
}

function add_review($data) {
    global $db;
    
    $query = "INSERT INTO reviews (guest_name, email, rating, comment, status) VALUES (?, ?, ?, ?, 'pending')";
    $stmt = $db->prepare($query);
    
    $stmt->execute([
        $data['name'],
        $data['email'],
        $data['rating'],
        $data['comment']
    ]);
    
    return true;
}

function add_contact_message($data) {
    global $db;
    
    $query = "INSERT INTO contacts (name, email, phone, subject, message, status) VALUES (?, ?, ?, ?, ?, 'new')";
    $stmt = $db->prepare($query);
    
    $stmt->execute([
        $data['name'],
        $data['email'],
        $data['phone'],
        $data['subject'],
        $data['message']
    ]);
    
    return true;
}

function register_user($data) {
    global $db;
    
    // Проверяем, существует ли пользователь
    $query = "SELECT id FROM users WHERE email = ? OR username = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$data['email'], $data['username']]);
    
    if ($stmt->rowCount() > 0) {
        return false; // Пользователь уже существует
    }
    
    // Хешируем пароль
    $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
    
    $query = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'user')";
    $stmt = $db->prepare($query);
    
    $stmt->execute([
        $data['username'],
        $password_hash,
        $data['email']
    ]);
    
    return true;
}

function authenticate_user($username, $password) {
    global $db;
    
    $query = "SELECT * FROM users WHERE username = ? AND role = 'user'";
    $stmt = $db->prepare($query);
    $stmt->execute([$username]);
    
    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (password_verify($password, $user['password'])) {
            return $user;
        }
    }
    
    return false;
}
?>