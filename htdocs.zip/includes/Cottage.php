<?php
// includes/Cottage.php
class Cottage {
    private $conn;
    private $table_name = "cottages";

    public $id;
    public $title;
    public $description;
    public $max_guests;
    public $price_per_night;
    public $bedrooms;
    public $amenities;
    public $image;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE status = 'active' ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($row) {
            $this->title = $row['title'];
            $this->description = $row['description'];
            $this->max_guests = $row['max_guests'];
            $this->price_per_night = $row['price_per_night'];
            $this->bedrooms = $row['bedrooms'];
            $this->amenities = $row['amenities'];
            $this->image = $row['image'];
            $this->status = $row['status'];
            return true;
        }
        return false;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET title=:title, description=:description, max_guests=:max_guests, 
                      price_per_night=:price_per_night, bedrooms=:bedrooms, 
                      amenities=:amenities, image=:image, status=:status";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":max_guests", $this->max_guests);
        $stmt->bindParam(":price_per_night", $this->price_per_night);
        $stmt->bindParam(":bedrooms", $this->bedrooms);
        $stmt->bindParam(":amenities", $this->amenities);
        $stmt->bindParam(":image", $this->image);
        $stmt->bindParam(":status", $this->status);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET title = :title, description = :description, max_guests = :max_guests, 
                      price_per_night = :price_per_night, bedrooms = :bedrooms, 
                      amenities = :amenities, image = :image, status = :status 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":max_guests", $this->max_guests);
        $stmt->bindParam(":price_per_night", $this->price_per_night);
        $stmt->bindParam(":bedrooms", $this->bedrooms);
        $stmt->bindParam(":amenities", $this->amenities);
        $stmt->bindParam(":image", $this->image);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":id", $this->id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>