<?php
// includes/config.php
define('SITE_NAME', 'База отдыха "Радужный"');
define('SITE_URL', 'http://localhost/baza-otdyha');
define('ADMIN_EMAIL', 'admin@raduzhny.ru');

// Подключение к базе данных
require_once 'db.php';

// Создаем подключение
$database = new Database();
$db = $database->getConnection();

// Подключаем функции
require_once 'functions.php';
?>